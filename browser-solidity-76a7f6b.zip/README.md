# Automatic build
Built website from `76a7f6b`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `browser-solidity-76a7f6b.zip`.
